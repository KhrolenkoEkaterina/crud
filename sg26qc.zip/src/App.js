import "./styles.css";
import Dish from "./Components/Dish/Dish";

function App() {
  return (
    <div className="App">
      <Dish />
    </div>
  );
}
export default App;
